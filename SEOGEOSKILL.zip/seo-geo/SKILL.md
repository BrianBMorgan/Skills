---
name: seo-geo
description: |
  SEO & GEO (Generative Engine Optimization) for websites.
  Analyze keywords, generate schema markup, optimize for AI search engines
  (ChatGPT, Perplexity, Gemini, Copilot, Claude) and traditional search (Google, Bing).
  Use when user wants to improve search visibility.
triggers:
  - SEO
  - GEO
  - search optimization
  - schema markup
  - JSON-LD
  - meta tags
  - keyword research
  - search ranking
  - AI visibility
  - ChatGPT ranking
  - Perplexity
  - Google AI Overview
  - indexing
metadata:
  mcpmarket-version: 1.1.0
---
# SEO/GEO Optimization Skill

Comprehensive SEO and GEO (Generative Engine Optimization) for websites. Optimize for both traditional search engines (Google, Bing) and AI search engines (ChatGPT, Perplexity, Gemini, Copilot, Claude).

## Quick Reference

**GEO = Generative Engine Optimization** — optimizing content to be *cited* by AI search engines.

**Key insight:** AI search engines don't rank pages — they **cite sources**. Being cited is the new "ranking #1". Two things earn citations: (1) the engine can **discover** the page (sitemap + crawlable + indexed), and (2) it can **confidently extract** facts from it (structured data + answer-first prose). Most sites have the plumbing but ship **no structured data** and **hide their best content from the sitemap** — fix those two first.

> **This skill is self-contained.** The `scripts/` and `references/` files referenced at the bottom are *optional* enrichment — every command and template you need is inline below. If they're missing, proceed; don't block on them.

## Workflow

### Step 1: Website Audit

Audit the live site with `curl` + `grep`/`python3` (no API, no script needed). Run these against the target URL and an inner content page (e.g. a blog post).

**Homepage meta + schema + canonical:**
```bash
curl -sL "https://example.com" \
  | grep -iE "<title>|name=\"description\"|name=\"keywords\"|property=\"og:|name=\"twitter:|application/ld\+json|rel=\"canonical\"|<html"
```

**Count JSON-LD blocks (0 = the #1 GEO gap):**
```bash
curl -sL "https://example.com" | grep -c "application/ld+json"
```

**robots.txt — who can crawl:**
```bash
curl -s "https://example.com/robots.txt"
```

**sitemap.xml — what's discoverable (CRITICAL: are blog/article URLs in here?):**
```bash
curl -s "https://example.com/sitemap.xml" | head -50
```

**Inner content page — does it carry Article/BlogPosting + FAQPage schema?**
```bash
curl -sL "https://example.com/blog/some-post" | grep -o '"@type": *"[^"]*"' | sort | uniq -c
```

**Verify AI bot access** — a permissive `User-agent: *  Allow: /` already allows **all** AI crawlers; you do NOT need per-bot allow lines. What matters is that none of these are *Disallowed*, and that authed/app/API paths *are*:
```
Googlebot · Bingbot (Bing/Copilot) · PerplexityBot · ChatGPT-User · GPTBot (OpenAI) · ClaudeBot / anthropic-ai · Google-Extended · CCBot
```

> ⚠️ **Audit gotcha — `grep` on built bundles.** `grep` treats large/minified files (and some served HTML) as *binary* and **silently prints nothing even on a match**. When checking a built JS/HTML asset for a string, use `grep -a` (force text) or `python3 -c "print('needle' in open('f').read())"`. Two minutes were lost once to "the string is missing!" when it was just grep suppressing binary matches.

### Step 2: Keyword Research

Use **WebSearch** for target keywords:
```
WebSearch: "{keyword} keyword difficulty"
WebSearch: "{keyword} search volume {year}"
WebSearch: "site:{competitor.com} {keyword}"
```
Analyze: search volume/difficulty, competitor strategies, long-tail opportunities, and **international/term collisions** (e.g. an acronym that means something else in another industry).

### Step 3: GEO Optimization (AI Search Engines)

Apply the **9 Princeton GEO Methods**:

| Method | Visibility Boost | How to Apply |
|--------|-----------------|--------------|
| **Cite Sources** | +40% | Add authoritative citations and references |
| **Statistics Addition** | +37% | Include specific numbers and data points |
| **Quotation Addition** | +30% | Add expert quotes with attribution |
| **Authoritative Tone** | +25% | Use confident, expert language |
| **Easy-to-understand** | +20% | Simplify complex concepts |
| **Technical Terms** | +18% | Include domain-specific terminology |
| **Unique Words** | +15% | Increase vocabulary diversity |
| **Fluency Optimization** | +15-30% | Improve readability and flow |
| ~~Keyword Stuffing~~ | **-10%** | **AVOID — hurts visibility** |

**Best combination:** Fluency + Statistics.

**FAQPage schema (+40% AI visibility; the #1 Perplexity citation format):**
```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "What is [topic]?",
    "acceptedAnswer": { "@type": "Answer", "text": "[direct answer with a statistic]." }
  }]
}
```
> 🔑 **FAQPage schema MUST match visible content.** Google requires the Q&A to be *visible on the page*, not schema-only — schema-only FAQ can be ignored or flagged. Render the visible FAQ and the JSON-LD **from one data source** so they can never drift (see Step 5).

**Content structure:** answer-first (the direct answer in the first sentence/paragraph), clear H1 > H2 > H3, bullets + numbered lists, comparison tables, short paragraphs (2–3 sentences).

### Step 4: Traditional SEO Optimization

**Meta tags template:**
```html
<title>{Primary Keyword} - {Brand} | {Secondary}</title>
<meta name="description" content="{compelling, keyword-rich, 150–160 chars}">
<link rel="canonical" href="{absolute canonical URL}">
<!-- Open Graph -->
<meta property="og:title" content="{Title}">
<meta property="og:description" content="{Description}">
<meta property="og:image" content="{1200x630 image}">
<meta property="og:url" content="{Canonical URL}">
<meta property="og:type" content="website"><!-- "article" on posts -->
<!-- Twitter (mirror OG) -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{Title}">
<meta name="twitter:description" content="{Description}">
<meta name="twitter:image" content="{Image}">
```

**JSON-LD schema by page type:** `Organization` (anchor the brand entity), `WebSite`, `SoftwareApplication`/`Product` (with `offers`), `BlogPosting`/`Article` (with `datePublished`/`dateModified`/author/publisher), `FAQPage`.

**Content checklist:** H1 contains the primary keyword · images have descriptive alt text · internal links to related content · external links `rel="noopener noreferrer"` · mobile-friendly · loads < 3s.

### Step 5: Implementation Patterns (what actually works in a real codebase)

This is the part most SEO guides skip. How you *ship* the markup matters as much as the markup.

**1. Identify the rendering model first — it dictates the fix.**
- **Static HTML files** → edit the `<head>`, or (better, see #2) inject at serve time.
- **Server-rendered / Express / SSR** → inject in the response path. *This is usually right.*
- **Client-only SPA** (e.g. the authed app) → typically you do NOT want SEO tags here at all (see #6); pre-render only public marketing/landing routes.

**2. Inject from ONE source of truth at serve time — don't hand-edit N HTML files.**
Editing the same Organization/canonical/Twitter block into 6 pages guarantees drift. Build the markup once and stamp it into the response (same pattern as a CSS-hash stamp):
```ts
// builders live in one module; the route handler injects before </head>
const decorate = (html: string, route: string): string => {
  const docs = [organizationLd(), webSiteLd()];
  if (route === '/product' || route === '/pricing') docs.push(softwareApplicationLd());
  if (MARKETING_FAQ[route]) docs.push(faqPageLd(MARKETING_FAQ[route]));
  const extras = [jsonLdScript(docs)];
  if (!/rel="canonical"/.test(html)) extras.push(`<link rel="canonical" href="${SITE_URL}${route}" />`);
  // mirror OG → Twitter only if absent (don't clobber existing tags)
  if (!/name="twitter:title"/.test(html)) extras.push(twitterFromOg(html));
  html = html.replace('</head>', `${extras.join('\n')}\n</head>`);
  // FAQPage schema must match VISIBLE content → render the section from the same data
  if (MARKETING_FAQ[route]) html = html.replace('</main>', `${renderFaqSection(MARKETING_FAQ[route])}</main>`);
  return html;
};
```

**3. Always escape `<` in inline JSON-LD** so the JSON can't break out of the `<script>`:
```ts
const jsonLdScript = (doc) =>
  `<script type="application/ld+json">${JSON.stringify(doc).replace(/</g, '\\u003c')}</script>`;
```

**4. Wire the entity graph with `@id`.** Give `Organization` a stable `@id` (e.g. `${SITE_URL}/#organization`) and reference it from `WebSite.publisher`, `BlogPosting.author`/`publisher`, `SoftwareApplication.publisher`. One coherent entity beats many disconnected blobs — this is what lets AI engines say "X is made by Y".

**5. The sitemap must include DB-driven content, not just static routes.**
A blog is the GEO citation surface — if it's not in `sitemap.xml`, engines may never discover it. Generate the sitemap **dynamically** (static pages + every published article, with `<lastmod>`), and **degrade gracefully** (serve the static set if the DB is down rather than 500):
```ts
const urls = [...staticUrls, `${SITE_URL}/articles`];
try { for (const a of await listArticles()) urls.push(`${SITE_URL}/articles/${a.slug}`); } catch {}
```

**6. Scope tag injection to a public-route ALLOWLIST — never the authenticated app.**
Inject only for an explicit set of marketing/content routes. Serve the authed app (`/app`, dashboards) raw, and **exclude it from both `robots.txt` (`Disallow: /app`) and the sitemap**. A stray `canonical`, `noindex`, or OG tag leaking into the app is a silent footgun. Verify by diffing what the app route emits vs. a marketing route.

**7. Re-use builders across surfaces.** The same `organizationLd()`/`webSiteLd()` feed both the static marketing pages and the server-rendered blog `<head>`, so the entity is identical everywhere.

### Step 6: Validate & Monitor

```bash
# Re-run the Step 1 curls and confirm: ld+json count > 0, canonical present,
# Article/FAQPage @types on content pages, articles present in sitemap.xml.

# Ping IndexNow (Bing/Yandex/etc. — NOT Google) for fast re-crawl after changes.
# Include NEW content URLs (articles), not just the static pages.
```
- **Headless note:** you usually can't `open` a browser. Google Rich Results Test (`search.google.com/test/rich-results`) and the Schema.org validator need a *public* URL — hand those links to the user; in-agent, validate structurally with the curls above + `python3 -c "import json,…"` on each extracted JSON-LD block.
- **Indexing check (manual):** `site:{domain}` on Google/Bing.

**Report template:**
```markdown
## SEO/GEO Report — {domain}
### Status:  Meta ✅/❌ · Canonical ✅/❌ · JSON-LD (Org/WebSite/Article/FAQ) ✅/❌ · AI bots ✅/❌ · Articles-in-sitemap ✅/❌ · Mobile ✅/❌ · Speed Xs
### Recommendations (priority order): 1… 2… 3…
### Applied: [ ] FAQPage  [ ] BlogPosting  [ ] Org/WebSite entity  [ ] dynamic sitemap  [ ] canonicals  [ ] Twitter cards
```

## Platform-Specific Optimization

### ChatGPT
- **Branded domain authority** (cited ~11% more than third-party); fresh content (updated < 30 days → ~3.2x citations); backlinks; match ChatGPT's answer format.

### Perplexity
- Allow **PerplexityBot**; **FAQ schema** (high citation rate); host **PDFs** (prioritized); semantic relevance over keywords.

### Google AI Overview (SGE)
- **E-E-A-T**; structured data; topical authority (content clusters + internal links); authoritative citations (+132% visibility).

### Microsoft Copilot / Bing
- **Bing indexing is required** for citation; Microsoft-ecosystem signals (LinkedIn/GitHub) help; speed < 2s; clear entity definitions.

### Claude AI
- Uses **Brave Search** indexing (not Google); high factual density; clean structural clarity for easy extraction.

## Gotchas & Lessons (field notes)

1. **0 JSON-LD is the most common gap.** Sites get titles/OG/robots right and ship *zero* structured data — fix this first; it's the biggest GEO lever.
2. **Blog missing from the sitemap.** The content you're producing for citations is often the part not listed. Always check, and make the sitemap dynamic.
3. **FAQPage must be visible** — schema-only fails Google's guideline. One data source → visible section + JSON-LD.
4. **Don't leak SEO/SPA tags into the authed app.** Allowlist public routes; `Disallow` + omit-from-sitemap the app.
5. **`grep` silently skips binary** — use `grep -a` / `python3` when inspecting built or minified output.
6. **Headless can't `open` validators** — validate structurally with curl/python; pass GUI-validator links to the user.
7. **Build-time env can hide your output.** If a page/app is built by a bundler gated on an env var (e.g. an SPA that only mounts when an auth publishable key is set at build), a build *without* that var can dead-code-eliminate the whole app and emit a stub — so "my tag isn't in the bundle" may be a build-config artifact, not a code bug. Verify with the env set the way prod/CI sets it.
8. **Verify the merged/served code, not a stale local checkout.** Audit what's actually deployed (or `git show origin/<branch>:path`), since a local working tree can lag the branch you shipped.

## References (optional enrichment — inline content above is sufficient)

- `references/platform-algorithms.md` — detailed ranking factors per platform
- `references/geo-research.md` — Princeton GEO research (9 methods)
- `references/schema-templates.md` — JSON-LD templates
- `references/seo-checklist.md` — full audit checklist
- `scripts/seo_audit.py` — optional one-shot auditor (the Step 1 curls replace it if absent)
