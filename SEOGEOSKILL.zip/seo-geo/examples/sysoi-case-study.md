# Case Study — sysoi.ai (B2B SaaS marketing site + DB-driven blog)

A real application of this skill. Target: `sysoi.ai` — an Express app serving a
static marketing site, a server-rendered blog (`/articles`), and an
authenticated React SPA (`/app`). Shows the audit → prioritize → ship → verify
loop, and the implementation patterns that mattered.

## 1. Audit (what we found)

| Area | Status | Detail |
|------|--------|--------|
| Title / meta / OG | ✅ | Homepage + articles well-formed |
| robots.txt | ✅ | `User-agent: *  Allow: /`; `/app`, `/api`, internal paths disallowed; sitemap declared |
| IndexNow | ✅ | already wired (Bing/Yandex) |
| Canonical (articles) | ✅ | correct per-article |
| **Structured data** | ❌ | **0 JSON-LD blocks sitewide** — no Organization, no Article; FAQPage only when an article happened to carry FAQs |
| **Articles in sitemap** | ❌ | sitemap = 6 static pages, **0 articles** (the blog — the citation surface — was undiscoverable) |
| Homepage canonical / Twitter | ⚠️ | no `<link rel=canonical>`; only `twitter:card` (no title/desc/image) |

**One-line diagnosis:** *plumbing right, but publishing with no structured data
and hiding the blog from the sitemap* — so AI engines could neither reliably
discover nor confidently cite the content.

## 2. Prioritize (highest leverage first)
- **P1** Articles into the sitemap (discovery).
- **P2** `BlogPosting` JSON-LD on every article (extraction).
- **P3** `Organization` + `WebSite` sitewide; `SoftwareApplication` on product/pricing (entity).
- **P4** `FAQPage` (visible + schema) on pricing/product.
- **P5** Homepage canonical + full Twitter cards.

Shipped as **two PRs**: P1+P2+P3 (the high-leverage trio), then P4+P5.

## 3. Implementation patterns that mattered

1. **One source of truth, injected at serve time.** A single `structuredData.ts`
   exports `organizationLd()/webSiteLd()/softwareApplicationLd()/blogPostingLd()/
   faqPageLd()`. The Express layer injects them before `</head>` per route — no
   hand-editing 6 HTML files, zero drift. Same pattern already used for CSS-hash
   stamping, so it fit the codebase.
2. **Dynamic sitemap.** Was a static boot-time string; made it query the DB for
   published articles (with `<lastmod>`) and **degrade to the static set if the DB
   is down** (serve a partial sitemap, never 500).
3. **FAQPage matched to visible content.** Pricing copy was statements, not Q&A —
   so we authored a real FAQ *data array*, rendered both the **visible** section
   (before `</main>`) and the JSON-LD from it. Schema can't drift from content.
4. **Entity graph via `@id`.** Organization `@id` referenced by WebSite.publisher,
   BlogPosting.author/publisher, SoftwareApplication.publisher.
5. **`<` escaped** in all inline JSON-LD.
6. **Allowlist scoping.** Injection runs only for an explicit set of marketing
   routes + `/articles`. The authed SPA (`/app`) is served raw and stays out of
   robots + sitemap. (Later explicitly re-verified: no tags leak into `/app`.)

## 4. Gotchas hit (now in the skill's field notes)
- **`grep` skipped a minified bundle silently** — looked like a string was
  "missing" until re-checked with `grep -a` / python.
- **Headless validation** — couldn't `open` the Rich Results Test; validated
  structurally with curl + JSON parsing instead, handing GUI-validator links over.
- **Keyless SPA build DCE** (adjacent discovery): a Vite build *without* the auth
  publishable key dead-code-eliminated the whole app into a stub — "my component
  isn't in the bundle" was a build-config artifact, not a bug. Verify with the
  env set the way CI/prod sets it.
- **Audit the deployed code** — a local checkout had drifted to a stale branch;
  re-checked against `git show origin/<branch>:path` / the live site.

## 5. Verify (after deploy)

`python3 scripts/seo_audit.py "https://sysoi.ai" "https://sysoi.ai/pricing"`:

```
HOME    : title ✅ · description ✅ · canonical ✅ · Twitter ✅ · JSON-LD 2 (Organization, WebSite)
robots  : /app, /api disallowed; sitemap declared
sitemap : 11 URLs — 6 marketing + /articles + 4 article posts   ← blog now discoverable
PRICING : JSON-LD 4 (Organization, WebSite, SoftwareApplication, FAQPage)   ← full coverage
```

**Outcome:** every page type now ships structured data, the blog is in the
sitemap, canonicals/Twitter cards are complete, and the authed app is untouched —
i.e. AI engines can now both **discover** and **confidently cite** the content.

## Takeaway
The biggest wins weren't fancy — *put structured data on the page* and *list your
content in the sitemap*. The craft was in **how** you ship it: one data source,
injected server-side, scoped to public routes, schema matched to visible content.
