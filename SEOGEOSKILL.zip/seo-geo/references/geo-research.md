# GEO Research — the 9 methods

GEO (Generative Engine Optimization) is the practice of structuring content so
**AI answer engines cite it**. The canonical study is *"GEO: Generative Engine
Optimization"* (Aggarwal et al., Princeton/IIT/Georgia Tech, 2023), which tested
content tactics against a generative-engine benchmark and measured citation /
visibility lift.

> **Read the boosts as directional, not guarantees.** The percentages are the
> paper's *relative* visibility improvements averaged across queries; real lift
> varies by domain, query type, and engine. Use them to prioritize, not to promise.

## The methods, ranked by reported lift

| # | Method | ~Boost | What it means in practice |
|---|--------|--------|---------------------------|
| 1 | **Cite Sources** | +40% | Back claims with authoritative, linkable references. Engines prefer content that itself looks sourced. |
| 2 | **Statistics Addition** | +37% | Replace vague claims with specific numbers ("44% of organizers don't connect their event platform to a CRM"). Quantified statements get extracted. |
| 3 | **Quotation Addition** | +30% | Add attributed expert quotes. Quotes are high-signal, citation-friendly units. |
| 4 | **Authoritative Tone** | +25% | Write with confident, declarative expertise — not hedged marketing fluff. |
| 5 | **Easy-to-understand** | +20% | Simplify. If a model can't cleanly parse the claim, it won't cite it. |
| 6 | **Technical Terms** | +18% | Use correct domain terminology — it raises topical authority and matches expert queries. |
| 7 | **Unique Words** | +15% | Vocabulary diversity; avoid repetitive, templated phrasing. |
| 8 | **Fluency Optimization** | +15–30% | Clean, well-structured, readable prose. Compounds with everything else. |
| — | ~~Keyword Stuffing~~ | **−10%** | **Actively hurts.** The old SEO reflex backfires with generative engines. |

**Highest-leverage combo:** *Fluency + Statistics.* Readable prose dense with
specific, sourced numbers is the most citable shape.

## Translating methods → page structure

The methods are about *content*; these are the *structural* habits that make the
content extractable:

- **Answer-first.** Put the direct answer in the opening sentence/paragraph, then
  elaborate. Engines lift the lede.
- **One idea per short paragraph** (2–3 sentences). Long blocks bury the citable unit.
- **Headings as questions.** `## How does event attribution work?` mirrors real
  prompts and maps cleanly to FAQ/Q&A extraction.
- **Tables for comparisons**, lists for steps/criteria — structured data the model
  can lift wholesale.
- **An explicit FAQ section** at the end of every substantial page (and matching
  `FAQPage` schema — see `schema-templates.md`). This is the single most
  citation-friendly structure on the page.

## Why structured data multiplies the content work

The Princeton methods make prose *citable*; JSON-LD makes facts *machine-certain*.
An engine that can read `BlogPosting` (who wrote it, when, what it's about) and
`FAQPage` (the exact Q→A pairs) doesn't have to infer — it extracts with
confidence, which is what citation requires. Do both: GEO content **and** schema.

## Discovery is a precondition

None of this matters if the engine can't reach the page. Before optimizing
content, confirm: crawlable (`robots.txt` allows the bot), in the `sitemap.xml`,
and indexed (Bing especially — Copilot and, indirectly, several engines lean on
Bing's index). GEO = **discoverable × extractable × authoritative.**
