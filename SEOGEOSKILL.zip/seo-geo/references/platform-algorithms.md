# Platform-Specific Ranking & Citation Factors

Every engine = **discover × extract × trust**. The differences below are about
which index they read, what structure they favor, and what they treat as
authority. Optimize the shared fundamentals (schema, answer-first, fresh,
crawlable) first, then tune per platform.

## ChatGPT (OpenAI — Search + browsing)

- **Index/sources:** its own crawl (GPTBot) + Bing-backed search + live browsing
  (ChatGPT-User). Allow both `GPTBot` and `ChatGPT-User` in `robots.txt`.
- **Favors:** branded/first-party domains (cited ~11% more than third-party
  aggregators), **freshness** (content updated within ~30 days cited ~3.2x more),
  strong backlink profiles, and content shaped like a direct answer.
- **Do:** keep `dateModified` honest and current; publish on your own domain;
  answer-first prose; clear headings.

## Perplexity

- **Index/sources:** real-time retrieval; heavy citation UI. Allow `PerplexityBot`.
- **Favors:** **FAQ schema** and Q&A structure (highest citation rate), **PDFs**
  (often prioritized as sources), strong semantic relevance over keyword density.
- **Do:** ship `FAQPage` + visible FAQ on every key page; consider a canonical
  PDF for cornerstone content; write to the *question*, not the keyword.

## Google AI Overviews (SGE / Gemini)

- **Index/sources:** Google's index; AI Overviews sit atop it. Allow `Googlebot`
  (and `Google-Extended` if you want Gemini training/grounding use).
- **Favors:** **E-E-A-T** (Experience, Expertise, Authoritativeness, Trust),
  structured data, **topical authority** (content clusters + internal linking),
  and authoritative outbound citations (reported ~+132% visibility).
- **Do:** build clusters (pillar + supporting posts, interlinked); add author/Org
  signals; cite sources; full structured-data coverage.

## Microsoft Copilot / Bing

- **Index/sources:** **Bing's index is the gate** — if you're not in Bing, you
  can't be cited here. Allow `Bingbot`.
- **Favors:** Microsoft-ecosystem signals (LinkedIn, GitHub presence), fast pages
  (< 2s), clear entity definitions.
- **Do:** verify in **Bing Webmaster Tools**; submit via **IndexNow** (Bing is the
  primary consumer); tighten performance; define entities crisply.

## Claude (Anthropic)

- **Index/sources:** uses **Brave Search** for web results (not Google). Allow
  `ClaudeBot` / `anthropic-ai`.
- **Favors:** high **factual density** (data-rich, specific), clean **structural
  clarity** (easy to extract), low fluff.
- **Do:** ensure the site is in **Brave Search**; lead with facts and numbers;
  keep structure clean (headings, lists, tables, FAQ).

## Crawler allow-list (put these through `robots.txt`)

| Engine | Bot user-agents |
|--------|-----------------|
| Google | `Googlebot`, `Google-Extended` (AI grounding/training) |
| Bing / Copilot | `Bingbot` |
| OpenAI / ChatGPT | `GPTBot`, `ChatGPT-User`, `OAI-SearchBot` |
| Perplexity | `PerplexityBot` |
| Anthropic / Claude | `ClaudeBot`, `anthropic-ai`, `Claude-Web` |
| Common Crawl (feeds many) | `CCBot` |

A permissive `User-agent: *` + `Allow: /` covers all of them — you only need
named entries to *block* something. Always `Disallow` authed/app/API paths.

## Cross-engine priority order (do these in order)

1. **Discoverable:** crawlable + in the sitemap + indexed (Bing especially).
2. **Structured:** Organization/WebSite sitewide; Article + FAQPage on content.
3. **Fresh & sourced:** honest `dateModified`, statistics, citations.
4. **Authoritative:** first-party domain, topical clusters, backlinks.
5. **Fast & clean:** < 2–3s, mobile-friendly, extractable structure.
