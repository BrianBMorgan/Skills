# JSON-LD Schema Templates

Copy-paste `schema.org` JSON-LD. Emit each as a `<script type="application/ld+json">`
block in the page `<head>`.

## Non-negotiable rules

1. **Escape `<`** in the serialized JSON so it can't break out of the script:
   `JSON.stringify(doc).replace(/</g, '\\u003c')`.
2. **Schema must match visible content.** Especially `FAQPage` — the Q&A must be
   rendered on the page, not schema-only. Drive both from one data source.
3. **Wire the entity graph with `@id`.** Give `Organization` a stable `@id` and
   reference it from `WebSite.publisher`, `Article.author`/`publisher`, etc.
4. **Use absolute URLs** everywhere (`https://…`), not relative paths.
5. **One coherent set per page** — don't duplicate/contradict across blocks.

## Organization (every page — the brand entity anchor)

```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://example.com/#organization",
  "name": "Example",
  "url": "https://example.com/",
  "logo": "https://example.com/logo.png",
  "description": "One-sentence description of what the company is.",
  "sameAs": [
    "https://www.linkedin.com/company/example",
    "https://x.com/example"
  ]
}
```
> Omit `sameAs` rather than inventing social URLs you can't confirm.

## WebSite (every page; add SearchAction only if you have site search)

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://example.com/#website",
  "name": "Example",
  "url": "https://example.com/",
  "publisher": { "@id": "https://example.com/#organization" },
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://example.com/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
```

## BlogPosting / Article (content pages)

```json
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "Article title (≤110 chars)",
  "description": "Meta-description-grade summary.",
  "image": "https://example.com/articles/post/hero.png",
  "url": "https://example.com/articles/post",
  "mainEntityOfPage": { "@type": "WebPage", "@id": "https://example.com/articles/post" },
  "datePublished": "2026-06-01T00:00:00.000Z",
  "dateModified": "2026-06-05T00:00:00.000Z",
  "author": { "@id": "https://example.com/#organization", "name": "Example" },
  "publisher": { "@id": "https://example.com/#organization" }
}
```
> Dates must be ISO 8601. `dateModified` feeds freshness signals (ChatGPT cites
> recently-updated content ~3.2x more) — keep it real, don't fake recency.

## FAQPage (+40% AI visibility; #1 Perplexity citation format)

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is the product?",
      "acceptedAnswer": { "@type": "Answer", "text": "Direct answer, ideally with a statistic." }
    },
    {
      "@type": "Question",
      "name": "How much does it cost?",
      "acceptedAnswer": { "@type": "Answer", "text": "Concrete pricing, no fluff." }
    }
  ]
}
```
> The questions/answers here MUST appear visibly on the page. Render the visible
> FAQ section and this JSON from the same array.

## SoftwareApplication (SaaS/tools — carry real pricing)

```json
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "Example",
  "applicationCategory": "BusinessApplication",
  "operatingSystem": "Web",
  "url": "https://example.com/",
  "description": "What it does, who it's for.",
  "publisher": { "@id": "https://example.com/#organization" },
  "offers": [
    { "@type": "Offer", "name": "Starter", "price": "24000", "priceCurrency": "USD",
      "priceSpecification": { "@type": "UnitPriceSpecification", "price": "24000", "priceCurrency": "USD", "unitText": "YEAR" } }
  ]
}
```

## Product (e-commerce / physical or licensed product)

```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Product name",
  "description": "Description.",
  "image": "https://example.com/product.png",
  "brand": { "@id": "https://example.com/#organization" },
  "offers": {
    "@type": "Offer",
    "price": "99.00",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock",
    "url": "https://example.com/product"
  }
}
```

## BreadcrumbList (deep pages — improves rich results + navigation context)

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://example.com/" },
    { "@type": "ListItem", "position": 2, "name": "Articles", "item": "https://example.com/articles" },
    { "@type": "ListItem", "position": 3, "name": "This Post", "item": "https://example.com/articles/post" }
  ]
}
```

## Validate

- Google Rich Results Test: `https://search.google.com/test/rich-results`
- Schema.org validator: `https://validator.schema.org/`
- Both need a **public URL** (or pasted code). In a headless/agent context,
  extract each block and `json.loads()` it to confirm it parses + has `@type`.
