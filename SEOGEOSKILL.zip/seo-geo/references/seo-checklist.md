# SEO / GEO Audit Checklist

Run top to bottom. `scripts/seo_audit.py` automates most of the Discovery +
Structured-data + Meta rows.

## 1. Discovery (can engines find it?)
- [ ] `robots.txt` exists, `Allow: /`, declares `Sitemap:`
- [ ] AI bots NOT blocked (GPTBot, ChatGPT-User, PerplexityBot, ClaudeBot, Bingbot, Googlebot)
- [ ] Authed/app/API paths **Disallowed** (`/app`, `/api`, internal tools)
- [ ] `sitemap.xml` exists and is valid XML
- [ ] **Sitemap lists content, not just the homepage** (blog/article URLs present)
- [ ] Sitemap is **dynamic** (new content shows up automatically) with `<lastmod>`
- [ ] Submitted to Google Search Console + Bing Webmaster Tools
- [ ] IndexNow ping on publish (includes new content URLs, not just static pages)
- [ ] Indexed: `site:{domain}` returns pages on Google AND Bing

## 2. Per-page meta (every indexable page)
- [ ] Unique `<title>` (primary keyword + brand)
- [ ] `meta description` 150–160 chars, compelling, keyword-aware
- [ ] `<link rel="canonical">` present + absolute + correct (esp. homepage)
- [ ] Open Graph: title, description, image (1200×630), url, type
- [ ] Twitter card: `summary_large_image` + title/description/image
- [ ] `<html lang>` set; viewport meta present
- [ ] No accidental `noindex` on public pages; **no SEO tags on the authed app**

## 3. Structured data (the #1 GEO lever)
- [ ] JSON-LD count > 0 on EVERY page type (0 is the most common gap)
- [ ] `Organization` + `WebSite` sitewide, wired with `@id`
- [ ] `SoftwareApplication`/`Product` on product/pricing (with `offers`)
- [ ] `BlogPosting`/`Article` on content (headline, dates, image, author, publisher)
- [ ] `FAQPage` on pricing/product/articles — **with matching visible Q&A**
- [ ] `BreadcrumbList` on deep pages
- [ ] All JSON-LD: absolute URLs, `<` escaped, validates (Rich Results / schema.org)
- [ ] One source of truth for schema (no per-file drift; generated, not hand-copied)

## 4. GEO content (citation-readiness)
- [ ] Answer-first: direct answer in the opening paragraph
- [ ] Statistics with citations (Princeton: +37% / +40%)
- [ ] Expert quotes with attribution where natural
- [ ] Authoritative, fluent tone — no keyword stuffing (−10%)
- [ ] Headings phrased as real questions
- [ ] Short paragraphs, lists, comparison tables
- [ ] An explicit FAQ section on substantial pages
- [ ] `dateModified` honest + current (freshness)

## 5. On-page / technical
- [ ] One `<h1>` containing the primary keyword; clean H1>H2>H3
- [ ] Descriptive `alt` on images
- [ ] Internal links to related content (topical clusters)
- [ ] External links `rel="noopener noreferrer"`
- [ ] Clean, readable, stable URLs (slugs, no junk params)
- [ ] HTTPS, no mixed content, correct 301s (no chains/loops)

## 6. Performance & mobile
- [ ] Loads < 3s (Bing/Copilot want < 2s)
- [ ] Core Web Vitals pass (LCP, INP, CLS) — PageSpeed Insights
- [ ] Mobile-friendly / responsive
- [ ] Image sizes + caching sane; render-blocking minimized

## 7. Don't-leak guardrails (learned the hard way)
- [ ] SEO/structured-data injection scoped to a **public-route allowlist**
- [ ] Authed SPA served raw (no canonical/OG/JSON-LD injected into `/app`)
- [ ] `/app` excluded from both robots (`Disallow`) and the sitemap
- [ ] Verified against the **deployed/merged** code, not a stale local checkout

## 8. Verification habits
- [ ] Re-run `seo_audit.py` after changes
- [ ] `grep -a` (or python) when inspecting built/minified output (grep skips binary)
- [ ] If output seems "missing," check build-time env (a bundler gated on an env
      var can DCE the whole app into a stub)
