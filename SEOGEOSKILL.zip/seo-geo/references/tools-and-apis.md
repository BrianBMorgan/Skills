# Tools & APIs

## Free, no-key (use these first — work in any sandbox/CI/agent)
- **`scripts/seo_audit.py`** (this skill) — title/meta/canonical/OG/Twitter/JSON-LD
  + robots + sitemap, stdlib only.
- **`curl` + `grep -aiE` / `python3`** — ad-hoc checks (see SKILL.md Step 1).
  Remember `grep` skips *binary* files silently → use `-a` or python on built assets.
- **`site:{domain}`** on Google/Bing — quick index check.

## Search engine consoles (verify + submit + monitor)
- **Google Search Console** — `https://search.google.com/search-console` — indexing,
  queries, Core Web Vitals, sitemap submission. Has an API for automation.
- **Bing Webmaster Tools** — `https://www.bing.com/webmasters` — Bing index =
  the gate for Copilot citations. Submit sitemap here too.

## Fast indexing
- **IndexNow** — `https://www.indexnow.org` — POST your changed URLs to
  `api.indexnow.org`; consumed by **Bing, Yandex, Seznam, Naver** (NOT Google).
  Host a `{key}.txt` verification file at the site root. Submit on every publish,
  and **include new content URLs** (articles), not just static pages.
  ```bash
  curl -X POST "https://api.indexnow.org/indexnow" -H "Content-Type: application/json" -d '{
    "host": "example.com",
    "key": "YOUR_KEY",
    "keyLocation": "https://example.com/YOUR_KEY.txt",
    "urlList": ["https://example.com/", "https://example.com/articles/new-post"]
  }'
  ```

## Schema validation (need a public URL or pasted code)
- **Google Rich Results Test** — `https://search.google.com/test/rich-results`
- **Schema.org Validator** — `https://validator.schema.org/`
- Headless fallback: extract each `application/ld+json` block and `json.loads()` it;
  confirm it parses and has `@type`.

## Performance
- **PageSpeed Insights** — `https://pagespeed.web.dev/` (Core Web Vitals: LCP/INP/CLS)
- **WebPageTest** — `https://www.webpagetest.org/` (waterfall, filmstrip)

## Keyword / competitive research (paid; use WebSearch as the free substitute)
- **Ahrefs**, **Semrush** — volume, difficulty, backlink profiles, competitor gaps.
- **Google Keyword Planner** — free with Ads account; volume ranges.
- **WebSearch (this harness)** — `"{keyword} keyword difficulty"`,
  `"{keyword} search volume {year}"`, `site:{competitor} {keyword}`.

## Crawlers / site-wide audits
- **Screaming Frog SEO Spider** — desktop crawler; broken links, redirects,
  duplicate titles, missing meta, schema extraction at scale.
- **Sitebulb** — similar, more guidance-oriented.

## AI-bot reference (for `robots.txt`)
See `platform-algorithms.md` for the full bot table (GPTBot, ChatGPT-User,
OAI-SearchBot, PerplexityBot, ClaudeBot, anthropic-ai, Google-Extended, Bingbot,
CCBot). A permissive `User-agent: *` covers them all; name them only to block.

## Rule of thumb
Start with the **free, no-key** tools — they catch the highest-leverage gaps
(missing JSON-LD, blog absent from sitemap, missing canonical) without any
account setup. Reach for consoles/paid tools for monitoring + competitive depth.
