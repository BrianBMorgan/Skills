#!/usr/bin/env python3
"""
Basic SEO/GEO auditor — stdlib only, no API keys, no pip installs.

Fetches a URL and reports the load-bearing SEO/GEO signals: title, meta
description, canonical, Open Graph, Twitter cards, JSON-LD types + count,
robots.txt bot access, and sitemap presence (+ whether it lists more than the
homepage). Designed to run anywhere (CI, an agent sandbox, your laptop).

Usage:
    python3 seo_audit.py "https://example.com"
    python3 seo_audit.py "https://example.com" "https://example.com/blog/a-post"

Exit code is 0 unless the primary URL can't be fetched.

NOTE (the GEO gaps this catches): JSON-LD count == 0 is the most common and
highest-leverage miss; a sitemap that only lists the homepage usually means the
blog/content (the citation surface) is undiscoverable.
"""
import json
import re
import sys
import urllib.request
import urllib.error
from urllib.parse import urljoin, urlparse

UA = "Mozilla/5.0 (compatible; seo-audit/1.1; +https://example.com/bot)"
TIMEOUT = 25


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return r.read().decode("utf-8", "replace")


def first(pattern, html, flags=re.I | re.S):
    m = re.search(pattern, html, flags)
    return m.group(1).strip() if m else None


def all_matches(pattern, html, flags=re.I | re.S):
    return [m.strip() for m in re.findall(pattern, html, flags)]


def jsonld_types(html):
    """Extract @type values from every application/ld+json block."""
    blocks = re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S,
    )
    types = []
    for b in blocks:
        try:
            data = json.loads(b.strip())
        except Exception:
            # fall back to a regex if the JSON is templated/imperfect
            types += re.findall(r'"@type"\s*:\s*"([^"]+)"', b)
            continue
        for node in data if isinstance(data, list) else [data]:
            if isinstance(node, dict) and "@type" in node:
                t = node["@type"]
                types += t if isinstance(t, list) else [t]
    return len(blocks), types


def yn(ok):
    return "OK " if ok else "MISS"


def audit_page(url, html, label="PAGE"):
    title = first(r"<title[^>]*>(.*?)</title>", html)
    desc = first(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']', html)
    canonical = first(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\'](.*?)["\']', html)
    og = all_matches(r'<meta[^>]+property=["\']og:([a-z:]+)["\']', html)
    tw = all_matches(r'<meta[^>]+name=["\']twitter:([a-z:]+)["\']', html)
    n_ld, types = jsonld_types(html)

    print(f"\n=== {label}: {url} ===")
    print(f"[{yn(title)}] <title>        {title or '(missing)'}")
    print(f"[{yn(desc)}] description    {(desc[:90] + '…') if desc and len(desc) > 90 else (desc or '(missing)')}")
    print(f"[{yn(canonical)}] canonical     {canonical or '(missing)'}")
    print(f"[{yn(og)}] Open Graph    {', '.join(sorted(set(og))) or '(none)'}")
    print(f"[{yn(tw)}] Twitter card  {', '.join(sorted(set(tw))) or '(none)'}")
    print(f"[{yn(n_ld)}] JSON-LD       {n_ld} block(s); types: {', '.join(types) or '(none)'}")
    if n_ld == 0:
        print("     ^ BIGGEST GEO GAP: no structured data. Add Organization + WebSite "
              "sitewide; Article/BlogPosting + FAQPage on content.")


def audit_robots_sitemap(base):
    origin = f"{urlparse(base).scheme}://{urlparse(base).netloc}"
    # robots.txt
    print(f"\n=== robots.txt: {origin}/robots.txt ===")
    sitemap_url = None
    try:
        robots = fetch(urljoin(origin + "/", "robots.txt"))
        print(robots.strip() or "(empty)")
        m = re.search(r"(?im)^\s*sitemap:\s*(\S+)", robots)
        if m:
            sitemap_url = m.group(1).strip()
        bad = [b for b in ("GPTBot", "PerplexityBot", "ClaudeBot", "Google-Extended")
               if re.search(rf"(?is)user-agent:\s*{b}.*?disallow:\s*/", robots)]
        if bad:
            print(f"     ^ WARNING: these AI bots are explicitly blocked: {', '.join(bad)}")
    except Exception as e:
        print(f"(could not fetch robots.txt: {e})")

    # sitemap
    sitemap_url = sitemap_url or urljoin(origin + "/", "sitemap.xml")
    print(f"\n=== sitemap: {sitemap_url} ===")
    try:
        sm = fetch(sitemap_url)
        locs = re.findall(r"<loc>(.*?)</loc>", sm, re.I | re.S)
        print(f"[{yn(locs)}] {len(locs)} URL(s)")
        for loc in locs[:12]:
            print(f"     - {loc.strip()}")
        if len(locs) > 12:
            print(f"     … +{len(locs) - 12} more")
        if len(locs) <= 1:
            print("     ^ Only the homepage is listed — your content/blog is likely "
                  "undiscoverable. Make the sitemap dynamic + include article URLs.")
    except Exception as e:
        print(f"(could not fetch sitemap: {e})")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    primary = argv[1]
    try:
        html = fetch(primary)
    except Exception as e:
        print(f"ERROR: could not fetch {primary}: {e}")
        return 1
    audit_page(primary, html, "HOME")
    audit_robots_sitemap(primary)
    for extra in argv[2:]:
        try:
            audit_page(extra, fetch(extra), "CONTENT")
        except Exception as e:
            print(f"\n(could not fetch {extra}: {e})")
    print("\nDone. Re-run after changes; aim for: JSON-LD > 0 on every page type, "
          "canonical present, content URLs in the sitemap.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
